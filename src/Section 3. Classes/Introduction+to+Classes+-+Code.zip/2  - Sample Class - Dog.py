class Dog:

	def __init__(self, name, age, vaccines):
		self.name = name
		self.age = age
		self.vaccines = vaccines

	def display_name(self):
		print(self.name)
